#discribe the patients table
DESCRIBE patients;

#discribe the admissions table
DESCRIBE admissions;

#discribe the doctors table
DESCRIBE doctors;

#discribe the province_names table
DESCRIBE province_names;

#q1 - Male patients
SELECT first_name, last_name, gender FROM patients WHERE gender = 'M';

#q2 - Patients without allergies
SELECT first_name, last_name FROM patients WHERE allergies IS NULL;

#q3 - First names starting with 'C'
SELECT first_name FROM patients WHERE first_name LIKE 'C%';

#q4 - Patients weighing between 100 and 120
SELECT first_name, last_name FROM patients WHERE weight BETWEEN 100 AND 120 ;

#q5 - Showing NULL allergies as 'NKA'
SELECT patient_id, first_name, last_name, IFNULL(allergies, 'NKA') AS allergies
FROM patients ;

#q6 - Full name in one column
SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM patients;

#q7 - Patient names with full province name
SELECT p.first_name, p.last_name, pn.province_name
FROM patients p
JOIN province_names pn ON p.province_id = pn.province_id;

#q8 - Patients born in 2010
SELECT COUNT(*) AS patients_born_2010 FROM patients WHERE YEAR(birth_date) = 2010;

#q9 - Patient with the greatest height
SELECT first_name, last_name, height FROM patients
WHERE height = (SELECT MAX(height) FROM patients);

#q10 - Patients with specific patient IDs
SELECT * FROM patients WHERE patient_id IN (1, 45, 534, 879, 1000);

#q11 - Total number of admissions
SELECT COUNT(*) AS total_admissions FROM admissions;

#q12 - Admitted and discharged on the same day
SELECT * FROM admissions WHERE admission_date = discharge_date;

#q13 - Total admissions for patient 579
SELECT COUNT(*) AS total_admissions FROM admissions WHERE patient_id = 579;

#q14 - Unique cities in province NS
SELECT DISTINCT city FROM patients WHERE province_id = 'NS';

#q15 - Height above 160 and weight above 70
SELECT first_name, last_name, birth_date FROM patients
WHERE height > 160 AND weight > 70;

#q16 - Unique birth years in ascending order
SELECT DISTINCT YEAR(birth_date) AS birth_year
FROM patients
ORDER BY birth_year ASC;

#q17 - First names that occur only once
SELECT first_name FROM patients
GROUP BY first_name
HAVING COUNT(*) = 1;

#q18 - First names starting and ending with 's'
SELECT patient_id, first_name FROM patients
WHERE first_name LIKE 's%s' AND LENGTH(first_name) >= 6;

#q19 - Patients diagnosed with Dementia
SELECT p.patient_id, p.first_name, p.last_name
FROM patients p
JOIN admissions a ON p.patient_id = a.patient_id
WHERE a.diagnosis = 'Dementia';

#q20 - First names ordered by length and alphabet
SELECT first_name FROM patients
ORDER BY LENGTH(first_name), first_name;

#q21 and q22 - Male and female patient counts
SELECT SUM(gender = 'M') AS male_count,SUM(gender = 'F') AS female_count
FROM patients;

#q23 - Patients admitted multiple times for the same diagnosis
SELECT patient_id, diagnosis
FROM admissions
GROUP BY patient_id, diagnosis
HAVING COUNT(*) > 1;

#q24 - Number of patients in each city
SELECT city, COUNT(*) AS total_patients
FROM patients
GROUP BY city
ORDER BY total_patients DESC, city ASC;

#q25 - Every patient and doctor with their role
SELECT first_name, last_name, 'Patient' AS role FROM patients
UNION ALL
SELECT first_name, last_name, 'Doctor' AS role FROM doctors;

#q26 - Allergies ordered by popularity
SELECT allergies, COUNT(*) AS popularity
FROM patients
WHERE allergies IS NOT NULL
GROUP BY allergies
ORDER BY popularity DESC;

#q27 - Patients born in the 1970s
SELECT first_name, last_name, birth_date
FROM patients
WHERE birth_date BETWEEN '1970-01-01' AND '1979-12-31'
ORDER BY birth_date ASC;

#q28 -Full names formatted as LASTNAME,firstname
• SELECT province_id, SUM(height) AS total_height
SELECT CONCAT(UPPER(last_name), ',', LOWER(first_name)) AS full_name
FROM patients
ORDER BY first_name DESC;

#q29 - Provinces with total height of 7,000 or more
SELECT province_id, SUM(height) AS total_height
FROM patients
GROUP BY province_id
HAVING SUM(height) >= 7000;

#q30 - Weight difference for last name 'Maroni'
SELECT MAX(weight) - MIN(weight) AS weight_difference
FROM patients
WHERE last_name = 'Maroni';

#q31 - Admissions by day of the month
SELECT DAY(admission_date) AS day_of_month, COUNT(*) AS total_admissions
FROM admissions
GROUP BY day_of_month
ORDER BY total_admissions DESC;

#q32 -Patients grouped by weight group
SELECT FLOOR(weight / 10) * 10 AS weight_group, COUNT(*) AS total_patients
FROM patients
GROUP BY weight_group
ORDER BY weight_group DESC;

#q33 - Obesity flag as 0 or 1
SELECT patient_id, weight, height,
CASE WHEN weight / POWER(height / 100, 2) >= 30 THEN 1 ELSE 0 END AS isObese
FROM patients;

#q34 - Epilepsy patients treated by doctor Lisa
SELECT p.patient_id, p.first_name, p.last_name, d.specialty
FROM patients p
JOIN admissions a ON p.patient_id = a.patient_id
JOIN doctors d ON a.attending_doctor_id = d.doctor_id
WHERE a.diagnosis = 'Epilepsy' AND d.first_name = 'Lisa';

#q35 - Temporary passwords for admitted patients
SELECT DISTINCT p.patient_id,
CONCAT(p.patient_id, LENGTH(p.last_name), YEAR(p.birth_date)) AS temp_password
FROM patients p
JOIN admissions a ON p.patient_id = a.patient_id;